export {};

Connector.playerSelector = 'body';

Connector.artistSelector = 'h1';

Connector.trackSelector = '.jp-title';

Connector.pauseButtonSelector = '.jp-pause';
