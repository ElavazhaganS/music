export {};

Connector.playerSelector = '.playlist';

Connector.trackSelector = '.track-title h2';

Connector.artistSelector = '.track-title h3';

Connector.trackArtSelector = '.playlist img';

Connector.playButtonSelector = '.play-button.fa-play';

Connector.onReady = Connector.onStateChanged;
