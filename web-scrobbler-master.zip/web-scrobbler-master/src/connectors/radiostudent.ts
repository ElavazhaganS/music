export {};

Connector.playerSelector = '#icecast_list';
Connector.artistTrackSelector = '#icecast_list > ul > li > p';
