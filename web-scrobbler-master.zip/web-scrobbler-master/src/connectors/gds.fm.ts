export {};

Connector.playerSelector = '.player-meta';

Connector.artistSelector = '.player-meta__artist';

Connector.trackSelector = '.player-meta__title';

Connector.playButtonSelector = '.player-meta__icon--play';
