export {};

Connector.playerSelector = '#player';

Connector.playButtonSelector = '#play-button';

Connector.artistSelector = '#track-artist';

Connector.albumSelector = '#track-album';

Connector.trackSelector = '#track-title';

Connector.trackArtSelector = '#track-art';

Connector.durationSelector = '#duration';

Connector.currentTimeSelector = '#time';
