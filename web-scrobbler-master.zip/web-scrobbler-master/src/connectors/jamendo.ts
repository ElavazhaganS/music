export {};

Connector.playerSelector = '.player-wrap';

Connector.artistSelector = '.player-mini_track_information_artist';

Connector.trackSelector = '.player-mini_track_information_title';

Connector.currentTimeSelector = '.hidden-xs > .js-player-position';

Connector.durationSelector = '.hidden-xs > .js-player-duration';

Connector.trackArtSelector = '.hero-cover img';

Connector.pauseButtonSelector = '.js-player-play-pause > .icon-pause';
