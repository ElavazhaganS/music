export {};

Connector.playerSelector = '#player';

Connector.artistTrackSelector = '#player div.rad-tracks > ul > li';

Connector.playButtonSelector = '.jp-play';
