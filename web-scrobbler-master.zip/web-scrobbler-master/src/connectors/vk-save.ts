export {};

Connector.playerSelector = '.popup_player_wrapper > .popup_player_content';

Connector.artistSelector = '.info_wr > .author > a';

Connector.trackSelector = '.info_wr > .info > .title';

Connector.currentTimeSelector = '.durations_wrap > .durations_start';

Connector.remainingTimeSelector = '.durations_wrap > .durations_end';

Connector.playButtonSelector = '.footer_player > .footer_play';
