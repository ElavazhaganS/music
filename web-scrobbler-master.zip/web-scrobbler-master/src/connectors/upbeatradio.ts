export {};

Connector.playerSelector = '#header';

Connector.trackArtSelector = '#stats > div > div.left.a > div.avatar > img';

Connector.artistSelector = '.stats-artist';

Connector.trackSelector = '.stats-song';

Connector.playButtonSelector = '#radioPlayer .fa-play';

Connector.onReady = Connector.onStateChanged;
