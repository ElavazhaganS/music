export {};

// Not a typo, this is spelled the same as the site.
Connector.playerSelector = '#player-controlls';
Connector.pauseButtonSelector = '.fa-pause';
Connector.durationSelector = '.track-length';
Connector.artistSelector = '.jp-artists';
Connector.trackSelector = '.jp-title';
