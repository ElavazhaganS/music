export {};

Connector.playerSelector = '.appPlayer';

Connector.artistTrackSelector = '.appPlayer__title';

Connector.playButtonSelector = '.appPlayer__play';
