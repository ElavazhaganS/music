export {};

Connector.playerSelector = '.player_ct.mini';
Connector.artistSelector = '.track_area .track_info .artist';
Connector.trackSelector = '.track_area .track_info .title';
Connector.pauseButtonSelector = '.control_area .icon-player.btn-player-pause';
Connector.trackArtSelector = '.playbar_ct .thumb';
Connector.durationSelector = '.time_all > span';
Connector.currentTimeSelector = '.time_current > span';
