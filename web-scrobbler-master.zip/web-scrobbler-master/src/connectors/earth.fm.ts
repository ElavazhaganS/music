export {};

Connector.playerSelector = '[class^=AudioPlayer__Wrapper]';

Connector.artistSelector = '[class^=AudioPlayer__Recordist]';

Connector.trackSelector = '[class^=AudioPlayer__Title]';

Connector.trackArtSelector = '[class^=AudioPlayer__CoverWrapper] picture img';

Connector.playButtonSelector = '[aria-label="Play"]';
