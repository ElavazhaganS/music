export {};

Connector.playerSelector = '.MiniSessionPlayer__PlayerBar-du0okt-4';
Connector.artistSelector = '.MiniSessionPlayer__Subtitle-du0okt-11';
Connector.trackSelector = '.MiniSessionPlayer__Title-du0okt-10';
Connector.trackArtSelector = '.MiniSessionPlayer__IconImage-du0okt-9';
Connector.currentTimeSelector = '.dBVUFV > .jVXvOE > .eDQGaR > .cwMKJQ';
Connector.durationSelector = '.dBVUFV > .jVXvOE > .eDQGaR > .eguLQa';
