export {};

Connector.playerSelector = '.miniplayer';

Connector.artistSelector = '.current-series-link';

Connector.trackSelector = '.current-episode-link';

Connector.playButtonSelector = '.play';
