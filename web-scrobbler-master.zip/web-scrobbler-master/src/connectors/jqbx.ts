export {};

Connector.playerSelector = 'body';

Connector.trackSelector = '.name > a';

Connector.artistSelector = '.artists > li > a';

Connector.playButtonSelector = '.resume';
