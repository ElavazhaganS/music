export {};

Connector.playerSelector = '.c-player__container';

Connector.artistSelector = '.c-song__artist';

Connector.trackSelector = '.c-song__title';

Connector.timeInfoSelector = '.c-player__time';

Connector.playButtonSelector = '.c-player__control-button--play';
