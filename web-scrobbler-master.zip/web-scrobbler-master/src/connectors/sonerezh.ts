export {};

Connector.playerSelector = '.navbar-player';

Connector.artistSelector = '.song-artist';

Connector.trackSelector = '.song-name';

Connector.currentTimeSelector = '.currentTime';

Connector.durationSelector = '.on-air .song-playtime';

Connector.pauseButtonSelector = '#play.glyphicon-pause';
