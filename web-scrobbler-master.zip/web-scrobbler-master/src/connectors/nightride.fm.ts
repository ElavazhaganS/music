export {};

// A more specific selector simply wouldn't work
Connector.playerSelector = 'body';

Connector.artistTrackSelector = '#nowplaying';

Connector.playButtonSelector = '#playerPlay';
