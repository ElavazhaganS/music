export {};

Connector.playerSelector = '#player';

Connector.artistSelector = '#trackartist';

Connector.trackSelector = '#tracktitle';

Connector.playButtonSelector = '#play';
