export {};

Connector.playerSelector = '.app-layout';

Connector.artistSelector = '.text .artist';

Connector.trackSelector = '.text .title';

Connector.playButtonSelector = '.controls .icon-play-outline';
