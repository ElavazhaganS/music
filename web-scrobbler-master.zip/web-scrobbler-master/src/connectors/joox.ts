export {};

Connector.useMediaSessionApi();

Connector.playerSelector = '#__next > div:nth-child(2) > div:nth-child(2)';

Connector.currentTimeSelector = '#currentTime';

Connector.playButtonSelector = '.playerIcon--play';
