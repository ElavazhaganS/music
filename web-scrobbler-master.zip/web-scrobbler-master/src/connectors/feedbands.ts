export {};

Connector.playerSelector = '#footer-player-widget';

Connector.artistSelector = '#footer-widget-song-info > p > :nth-child(2)';

Connector.trackSelector = '#footer-widget-song-info > p > :nth-child(1)';

Connector.trackArtSelector = '#footer_widget_song_thumb';

Connector.timeInfoSelector = '#player-time';

Connector.playButtonSelector = '.icon-play';
