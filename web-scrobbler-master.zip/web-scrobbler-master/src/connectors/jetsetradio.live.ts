export {};

Connector.artistTrackSelector = '#programInformationText';
Connector.playerSelector = '#programInformationText';
