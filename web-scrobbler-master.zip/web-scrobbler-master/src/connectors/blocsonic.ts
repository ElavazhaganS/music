export {};

Connector.playerSelector = '#sp-container';

Connector.pauseButtonSelector = '.spi-pause-alt';

Connector.artistTrackSelector = '.sp-title';

Connector.currentTimeSelector = '.sp-time-position';

Connector.durationSelector = '.sp-length';
