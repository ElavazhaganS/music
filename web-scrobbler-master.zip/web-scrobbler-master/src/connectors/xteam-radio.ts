export {};

Connector.playerSelector = '.now-playing-bar--container';

Connector.pauseButtonSelector = '.play-pause-button--pause-container';

Connector.trackSelector =
	'.song-info--container.now-playing-bar--song-info > .song-info--name';

Connector.artistSelector =
	'.song-info--container.now-playing-bar--song-info > .song-info--artist-name';

Connector.albumSelector =
	'.song-info--container.now-playing-bar--song-info > .song-info--album-name';
