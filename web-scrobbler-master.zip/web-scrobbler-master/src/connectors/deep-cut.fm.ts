export {};

Connector.playerSelector = '.room-view-board';

Connector.artistSelector = '.songboard-artist';

Connector.trackSelector = '.songboard-song';

Connector.currentTimeSelector = '.songboard-time';

Connector.remainingTimeSelector = '.songboard-time-left';

Connector.applyFilter(MetadataFilter.createYouTubeFilter());
