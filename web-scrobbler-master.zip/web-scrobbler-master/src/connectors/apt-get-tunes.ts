export {};

Connector.useMediaSessionApi();
Connector.playerSelector = '#player';
