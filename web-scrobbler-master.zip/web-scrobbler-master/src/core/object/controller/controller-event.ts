export const ControllerReset = 'ControllerReset';

export const SongNowPlaying = 'SongNowPlaying';

export const SongUnrecognized = 'SongUnrecognized';
