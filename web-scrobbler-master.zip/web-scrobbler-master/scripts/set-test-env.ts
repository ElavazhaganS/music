process.env.VITE_TEST = 'true';
