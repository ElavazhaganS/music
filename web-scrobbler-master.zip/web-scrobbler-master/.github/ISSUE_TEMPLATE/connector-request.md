---
name: Connector request
about: Suggest a new connector to implement
title: ''
labels: connector, request
assignees: ''

---

**Provide information about website**
A short description of the website, sample URLs, (demo) accounts for testing purposes. If (demo) accounts are not for public use, you can mail them to the project developers.

**Additional context**
Add any other context or screenshots about the request here.
